(function(exports) {
    'use strict';
    //initialize the app
    var settings = {
      
    };

    exports.app = new App(settings);
}(window));
