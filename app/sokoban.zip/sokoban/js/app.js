/* Main Application
 *
 * This module initializes the application and handles
 * transition between different views
 *
 */

(function(exports) {
    "use strict";

   /**
    * The 'pause' event is fired when the app is sent to the background (app completely hidden) or when its partially obscured
    */
    function onPause() {

    }

   /**
    * The 'resume' event is fired when the app is brought to the foreground (app completely visible) including when the Voice Search Dialog is dismissed
    */
    function onResume() {
         
    }

   /**
    * Add listeners for pause and resume when the platform is ready
    */
    function onAmazonPlatformReady() {
        document.addEventListener("pause" , onPause, false);
        document.addEventListener("resume" , onResume, false);
    }

   /**
    * Handle device rotation event
    * When in portrait mode put up the app overlay div and notify the user
    * to change back to landscape
    */
    function handleDeviceOrientation() {
        //disregard on FireTV
        if(navigator.userAgent.match(/AFT/i)) {return;}

    }

    document.addEventListener("amazonPlatformReady" , onAmazonPlatformReady, false);
    window.addEventListener('orientationchange', handleDeviceOrientation, false);

   /**
    * The app object : the controller for the app, it creates views, manages navigation between views
    *                  routes input to the currently focused view, giving data to the views, and otherwise stitching things together
    * @param {Object} settingsParams settings for the application
    *                 settingsParams.dataURL {String} url of the initial data request
    *                 settingsParams.displayButtons {Boolean} flag that tells the app to display the buttons or not
    */
    function App(settingsParams) {
      var app = angular.module('sokoban', [
        'ngRoute',
        'sokoban.gameView',
        'sokoban.grid'
      ]).
      config(['$routeProvider', function($routeProvider) {
        $routeProvider.otherwise({redirectTo: '/game-view'});
      }]);
    }

    exports.App = App;
}(window));
