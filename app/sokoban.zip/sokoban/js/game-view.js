'use strict';

/* global angular */
/* global google */

angular.module('sokoban.gameView', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/game-view', {
    templateUrl: 'assets/game-view.html',
    controller: 'GameViewCtrl'
  });
}])

.controller('GameViewCtrl', ['$scope', 'sokoban.grid.factory', function($scope, gridFactory) {

  $scope.status = { text: "Welcome - choose a level", gamesCompleted: 0 };

  gridFactory.loadGames("sokoban-levels-plus", function(games) {
    $scope.games = games;
    $scope.status.gamesCompleted = 0;

    $scope.games.forEach(function(g) {
      if(g.complete) $scope.status.gamesCompleted++;
    });

    $scope.loadGame = function(game, reload){
      $scope.currentGame = game.load(reload);
      $scope.currentGame.grid.onComplete = notifyComplete;
      $scope.status.text = ($scope.currentGame.complete ? "" : "Prepare to lose");

    };
  });

  $scope.currentGame = gridFactory.create(10);
  $scope.currentGame.grid.onComplete = notifyComplete;

  function notifyComplete(player) {
    $scope.status.text = "Yee ha...you've completed " + $scope.currentGame.name + ". Please select another level.";
    $scope.status.gamesCompleted++;
  };

  // google.charts.setOnLoadCallback(drawStats);

	function drawStats() {

		var data = [];

		var tableData = google.visualization.arrayToDataTable(data);

		var options = {
			title: '',
			hAxis: {title: 'x'},
			vAxis: {title: 'y'}
		};

		var chart = new google.visualization.BarChart(document.getElementById('stats-chart'));

		chart.draw(tableData, options);
	}

}]);
