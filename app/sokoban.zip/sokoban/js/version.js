'use strict';

angular.module('sokoban.version', [
  'sokoban.version.interpolate-filter',
  'sokoban.version.version-directive'
])

.value('version', '0.1');
